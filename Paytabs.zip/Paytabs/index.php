<?php

ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);
$headers = array(
  "Authorization: SRJNKH6WTW-J6JRMKTTZ9-DHKTWMBKTD",
  "Content-type: application/json",
);
$url = "https://secure-global.paytabs.com/payment/request";
$data = array(
    "profile_id" => 119496,
	"tran_type"=>"auth",
    "tran_class" => "ecom",
	"cart_description" => "Testing Order",
	"cart_id" => (string)time(),
	"cart_currency" => "INR",
	"cart_amount" => "0.10",
	"callback" => "https://waytoweb.info/fomopay/Paytabs/success.php",
	"return" => "https://waytoweb.info/fomopay/Paytabs/cancel.php",
);

$postdata = json_encode($data);
$ch = curl_init($url); 
curl_setopt($ch, CURLOPT_POST, 1);
curl_setopt($ch, CURLOPT_POSTFIELDS, $postdata);
curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1); 
curl_setopt($ch, CURLOPT_HTTPHEADER, $headers);
$result = curl_exec($ch);
$status_code = curl_getinfo($ch, CURLINFO_HTTP_CODE);   //get status code
//echo $status_code;
echo "<pre>";
curl_close($ch);
$response = json_decode($result);
echo "<pre>";
print_r($response);
if(!empty($response)){
	
	header("Location:".$response->redirect_url);
}
die;
?>	