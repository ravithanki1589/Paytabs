<?php

echo "<pre>";
print_r($_POST);
print_r($_GET);
$rawPostData = file_get_contents('php://input');
print_r($rawPostData);
?>